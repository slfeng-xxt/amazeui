Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = require('./lib/mobile');
exports.connect = require('react-redux').connect;
