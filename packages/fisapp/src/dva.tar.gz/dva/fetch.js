
module.exports = require('isomorphic-fetch');
