This example was moved to [dvajs/dva-example-user-dashboard](https://github.com/dvajs/dva-example-user-dashboard).

本示例已被移到 [dvajs/dva-example-user-dashboard](https://github.com/dvajs/dva-example-user-dashboard)。
