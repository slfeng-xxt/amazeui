# Count (umd)

---

## Usage

```bash
$ npm install
$ npm run build -- --watch
```

Then open `index.html` in your browser.
