# Count

---

## Usage

```bash
$ npm install
$ npm start
```
