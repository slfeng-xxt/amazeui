# Friend List

---

## 

https://github.com/DerekCuevas/friend-list

## Demo

![](https://github.com/DerekCuevas/friend-list/raw/master/friendlist.gif)

## Usage

```bash
$ npm install
$ npm start
```
