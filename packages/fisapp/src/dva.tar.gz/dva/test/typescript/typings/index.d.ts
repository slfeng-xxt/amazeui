/// <reference path="globals/react-dom/index.d.ts" />
/// <reference path="globals/react-router/history/index.d.ts" />
/// <reference path="globals/react-router/index.d.ts" />
/// <reference path="globals/react/index.d.ts" />
