module.exports = require('react-router');
module.exports.routerRedux = require('react-router-redux');
