
module.exports = require('redux-saga');
