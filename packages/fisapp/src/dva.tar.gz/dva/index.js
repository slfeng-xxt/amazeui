Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = require('./src');
exports.connect = require('react-redux').connect;
