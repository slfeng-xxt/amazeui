import * as routerRedux from 'react-router-redux';

export * from 'react-router';
export { routerRedux };
