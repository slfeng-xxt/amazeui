import createDva from './createDva';

export default createDva({
  mobile: true,
});
