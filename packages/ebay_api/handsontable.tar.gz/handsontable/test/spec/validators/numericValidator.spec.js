describe('numericValidator', function () {
  var id = 'testContainer';

  beforeEach(function () {
    this.$container = $('<div id="' + id + '"></div>').appendTo('body');
  });

  afterEach(function () {
    if (this.$container) {
      destroy();
      this.$container.remove();
    }
  });

  var arrayOfObjects = function () {
    return [
      {id: 1, name: "Ted", lastName: "Right"},
      {id: 2, name: "Frank", lastName: "Honest"},
      {id: 3, name: "Joan", lastName: "Well"},
      {id: 4, name: "Sid", lastName: "Strong"},
      {id: 5, name: "Jane", lastName: "Neat"},
      {id: 6, name: "Chuck", lastName: "Jackson"},
      {id: 7, name: "Meg", lastName: "Jansen"},
      {id: 8, name: "Rob", lastName: "Norris"},
      {id: 9, name: "Sean", lastName: "O'Hara"},
      {id: 10, name: "Eve", lastName: "Branson"}
    ];
  };

  it('should validate an empty string (default behavior)', function (done) {
    var onAfterValidate = jasmine.createSpy('onAfterValidate');

    handsontable({
      data: arrayOfObjects(),
      columns: [
        {data: 'id', type: 'numeric'},
        {data: 'name'},
        {data: 'lastName'}
      ],
      afterValidate : onAfterValidate
    });

    setDataAtCell(2, 0, '');

    setTimeout(function () {
      expect(onAfterValidate).toHaveBeenCalledWith(true, '', 2, 'id', undefined, undefined);
      done();
    }, 100);
  });

  it('should not validate non numeric string', function (done) {
    var onAfterValidate = jasmine.createSpy('onAfterValidate');

    handsontable({
      data: arrayOfObjects(),
      columns: [
        {data: 'id', type: 'numeric'},
        {data: 'name'},
        {data: 'lastName'}
      ],
      afterValidate : onAfterValidate
    });

    setDataAtCell(2, 0, 'test');

    setTimeout(function () {
      expect(onAfterValidate).toHaveBeenCalledWith(false, 'test', 2, 'id', undefined, undefined);
      done();
    }, 100);
  });

  it('should validate numeric string', function (done) {
    var onAfterValidate = jasmine.createSpy('onAfterValidate');

    handsontable({
      data: arrayOfObjects(),
      columns: [
        {data: 'id', type: 'numeric'},
        {data: 'name'},
        {data: 'lastName'}
      ],
      afterValidate : onAfterValidate
    });

    setDataAtCell(2, 0, '123');

    setTimeout(function () {
      expect(onAfterValidate).toHaveBeenCalledWith(true, 123, 2, 'id', undefined, undefined);
      done();
    }, 100);
  });

  it('should validate signed numeric string', function (done) {
    var onAfterValidate = jasmine.createSpy('onAfterValidate');

    handsontable({
      data: arrayOfObjects(),
      columns: [
        {data: 'id', type: 'numeric'},
        {data: 'name'},
        {data: 'lastName'}
      ],
      afterValidate : onAfterValidate
    });

    setDataAtCell(2, 0, '-123');

    setTimeout(function () {
      expect(onAfterValidate).toHaveBeenCalledWith(true, -123, 2, 'id', undefined, undefined);
      done();
    }, 100);
  });

  describe("allowEmpty", function() {
    it('should not validate an empty string when allowEmpty is set as `false`', function (done) {
      var onAfterValidate = jasmine.createSpy('onAfterValidate');

      handsontable({
        data: arrayOfObjects(),
        columns: [
          {data: 'id', type: 'numeric', allowEmpty: false},
          {data: 'name'},
          {data: 'lastName'}
        ],
        afterValidate : onAfterValidate
      });

      setDataAtCell(2, 0, '');

      setTimeout(function () {
        expect(onAfterValidate).toHaveBeenCalledWith(false, '', 2, 'id', undefined, undefined);
        done();
      }, 100);
    });

    it('should not validate `null` when allowEmpty is set as `false`', function (done) {
      var onAfterValidate = jasmine.createSpy('onAfterValidate');

      handsontable({
        data: arrayOfObjects(),
        columns: [
          {data: 'id', type: 'numeric', allowEmpty: false},
          {data: 'name'},
          {data: 'lastName'}
        ],
        afterValidate : onAfterValidate
      });

      setDataAtCell(2, 0, null);

      setTimeout(function () {
        expect(onAfterValidate).toHaveBeenCalledWith(false, null, 2, 'id', undefined, undefined);
        done();
      }, 100);
    });

    it('should not validate `undefined` when allowEmpty is set as `false`', function (done) {
      var onAfterValidate = jasmine.createSpy('onAfterValidate');

      handsontable({
        data: arrayOfObjects(),
        columns: [
          {data: 'id', type: 'numeric', allowEmpty: false},
          {data: 'name'},
          {data: 'lastName'}
        ],
        afterValidate : onAfterValidate
      });

      setDataAtCell(2, 0, void 0);

      setTimeout(function () {
        expect(onAfterValidate).toHaveBeenCalledWith(false, void 0, 2, 'id', undefined, undefined);
        done();
      }, 100);
    });

    it('should validate 0 when allowEmpty is set as `false`', function (done) {
      var onAfterValidate = jasmine.createSpy('onAfterValidate');

      handsontable({
        data: arrayOfObjects(),
        columns: [
          {data: 'id', type: 'numeric', allowEmpty: false},
          {data: 'name'},
          {data: 'lastName'}
        ],
        afterValidate : onAfterValidate
      });

      setDataAtCell(2, 0, 0);

      setTimeout(function () {
        expect(onAfterValidate).toHaveBeenCalledWith(true, 0, 2, 'id', undefined, undefined);
        done();
      }, 100);
    });

    it('should add / remove `htInvalid` class properly when validating non-numeric data', function (done) {
      var hot = handsontable({
        data: [
          {id: 1, name: "Ted", salary: 10000},
          {id: 2, name: "Frank", salary: '5300'},
          {id: 3, name: "Joan", salary: 'non-numeric value'}
        ],
        columns: [
          {data: 'id'},
          {data: 'name'},
          {data: 'salary', type: 'numeric', allowInvalid: false}
        ]
      });

      hot.validateCells();

      setTimeout(function () {
        expect($(getCell(1, 2)).hasClass(hot.getSettings().invalidCellClassName)).toBe(false);
        expect($(getCell(2, 2)).hasClass(hot.getSettings().invalidCellClassName)).toBe(true);

        setDataAtCell(2, 2, 8000);
      }, 200);

      setTimeout(function () {
        expect($(getCell(2, 2)).hasClass(hot.getSettings().invalidCellClassName)).toBe(false);
        done();
      }, 400);
    });
  });
});
