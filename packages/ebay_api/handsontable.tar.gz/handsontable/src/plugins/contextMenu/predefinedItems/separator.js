export const KEY = '---------';

export function separatorItem() {
  return {
    name: KEY
  };
}
